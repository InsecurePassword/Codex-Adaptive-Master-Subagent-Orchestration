# AMS 4.0 implementation notes

AMS 4.0 preserves root authority and adaptive routing while adding gated quality controls:

- one extensible contract; retired `schema_version` is inert;
- explicit lazy routes, including named governance while full governance is off;
- default-on convergence with separate correction/redesign limits, deterministic IDs/receipts, recent candidate history, trigger-time write preflight, shared stale-recoverable locking, leases/fencing, immutable history, and archive/prune;
- fallback only after failed/blocked convergence releases custody, with independent validation unchanged;
- one canonical work-order/result envelope plus specialized addenda;
- compatibility-gated app-task/observation companions; standalone Sol Ultra excludes standard convergence;
- release verification outside the manifest and no AMS runtime test subsystem.

Selective exact prompt-edge repetition remains excluded.
