# Adaptive Master–Subagent Orchestration

**Release: 4.0**

AMS keeps GPT-5.6 Sol Max in charge while routing bounded work to the lowest-cost reliable model and reasoning effort. The root alone spawns, integrates, accepts, and communicates; workers are leaves, managers request root-mediated descendants, one writer owns each mutable surface, and profiles grant no permissions.

## Install

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "irm 'https://github.com/InsecurePassword/Codex-Adaptive-Master-Subagent-Orchestration/raw/refs/heads/main/install.ps1' | iex"
```

```bash
curl -fsSL 'https://github.com/InsecurePassword/Codex-Adaptive-Master-Subagent-Orchestration/raw/refs/heads/main/install.sh' | bash
```

The installer writes only the core skill and 18 profiles; it does not edit general Codex settings, project settings, OS permissions, or companions. See [INSTALLATION.md](INSTALLATION.md).

## Configuration and controls

Project settings fully replace global settings:

```text
<project-root>/.codex/ams-orchestration.toml
$CODEX_HOME/ams-orchestration.toml
```

Missing supported fields use current defaults. Unknown fields fail closed except retired top-level `schema_version`, which is ignored and removed on the next authorized write. Settings survive package operations. The normative contract is `adaptive-master-subagent-orchestration/references/project-control.md`.

```text
AMS STATUS
AMS ENABLE | AMS DISABLE
AMS MODE auto|minimal|balanced|moderate|heavy|extreme
AMS GOVERNANCE on|off | AMS ROOT FALLBACK on|off
AMS FEATURE <name> on|off
AMS CONVERGENCE CORRECTIONS <2-12> | AMS CONVERGENCE REDESIGNS <1-12>
AMS CONVERGENCE ARCHIVE <directory> | AMS CONVERGENCE PRUNE <archive-manifest>
AMS CONFIGURATION UPDATE [PROJECT|GLOBAL]
AMS SPARK on|off | AMS SPARK RECHECK | AMS SPARK EFFORTS low,medium,high
AMS PROFILES auto|installer
```

Canonical commands persist named project settings. Temporary overrides must explicitly name the AMS feature/limit; requesting an outcome does not enable a disabled module.

## Modular capabilities

| Capability | Default | Trigger |
|---|---:|---|
| Convergence control | on | repeated repair/review detection or bounded state/status/finalization/history work |
| Work-order refinement | off | exceptional high-risk/state-transfer addendum |
| Evidence-bound review | off | commissioned review |
| Shared-worktree verification | off | multiple writers share one tree |
| Runtime observation | off | required/conflicting identity evidence |
| Untrusted-evidence handling | off | bounded inspection/relay of untrusted output |
| Task-graph safeguards | off | enhanced dependency/ownership admission |
| Rejected-approach handoff | off | useful bounded rejected-path context |
| Request accounting | off | explicit objective-scoped accounting request |
| App-task lane | off | explicit authorization plus compatible companion |

A setting alone does nothing. A trusted project-native equivalent supersedes the optional module.

Convergence defaults to four correction cycles per epoch and four material redesigns per parent campaign. It uses deterministic IDs/receipts, bounded package-local records, a shared lease lock, generation checks, recent candidate receipts, immutable history, and explicit archive/prune. Generic “fix everything/do not stop/until clean” wording never bypasses it. `AMS STATUS` is physically read-only.

## Companions and routing

Optional companions:

- `ams-app-task-lane`: visible Codex app-task/worktree transport;
- `ams-runtime-observation`: local rollout-metadata corroboration.

Each requires AMS 4.0 compatibility and its own gate; it cannot bypass another toggle or become a competing orchestrator. Sol Ultra is a reduced standalone mode without standard convergence, including inside app tasks.

Spark handles bounded mechanics; Luna low-risk repetition; Terra normal implementation/review/investigation; Sol ambiguous, architectural, security-sensitive, difficult, or expensive-to-fail work. Intensities change topology, not quality or acceptance. Zergling Rush requires separate current-turn consent.

## Requirements

- Codex with skills/custom subagents;
- top-level GPT-5.6 Sol Max or verified Max-equivalent;
- PowerShell 5.1+ on Windows, or Bash and commands listed in [INSTALLATION.md](INSTALLATION.md).

Python is not a core requirement; release verification and the optional observation companion may use it.
