# Product Documentation

**Product:** Adaptive Master–Subagent Orchestration
**Release:** 4.0

## Boundary

A GPT-5.6 Sol Max root controls objective, graph, physical dispatch, hierarchy, adaptive model/effort routing, ownership, integration, acceptance, and user communication. Workers are leaves; managers request root-mediated descendants; profiles remain permission-neutral.

## Components and configuration

Core writes `$HOME/.agents/skills/adaptive-master-subagent-orchestration/` and `$CODEX_HOME/agents/ams_*.toml`; it does not edit general Codex settings or OS permissions. Project/global AMS settings are preserved. The master contract, defaults, precedence, validation, controls, and retired-field handling are normative in `adaptive-master-subagent-orchestration/references/project-control.md`.

Convergence tracking/history is the only AMS-specific durable runtime state. It is created only after trigger-time preflight and governed by `references/convergence-control.md`; status is lock-free/read-only.

## Architecture

`SKILL.md` bootstraps/routes. `runtime-core.md` defines authority, adaptive routing, canonical work orders/results, capability gates, lightweight convergence detection, and completion. Each rare capability has one lazy normative file. Release verification and size measurement remain outside the manifest.

Governance adds lifecycle, proportional review, convergence, acceptance, and handoff without changing core authority. A direct turn may invoke named governance while full governance is off.

Convergence separately counts correction cycles per epoch and redesigns per deterministic parent campaign. It uses canonical IDs/receipts, a stale-recoverable shared lock, ownership leases, generation fencing, recent candidate receipts, self-contained pending terminal state, immutable verified history, and explicit archive/prune. Root fallback cannot preempt active convergence and always retains independent validation. Sol Ultra excludes standard convergence.

Feature names/overrides are normative in `references/feature-control.md`. Optional modules require enablement/override, trigger, and no trusted project-native owner. App-task and local observation are compatibility-gated companions.

Installers validate manifest generations, lengths/hashes, profiles, canonical runtime state, and exact state preservation. Downgrade preparation exports runtime and preserves full 4.0 settings before creating target-compatible live settings.

## Layout

```text
Codex-Adaptive-Master-Subagent-Orchestration/
├── README.md
├── INSTALLATION.md
├── PRODUCT DOCUMENTATION.md
├── SOL-ULTRA-AMS-EXTREME-ORCHESTRATION-PROMPT.md
├── install-manifest.txt
├── install.ps1
├── install.sh
├── adaptive-master-subagent-orchestration/
│   ├── SKILL.md
│   ├── VERSION
│   ├── agents/openai.yaml
│   ├── assets/agent-profiles/
│   └── references/
└── extensions/
    ├── ams-app-task-lane/
    └── ams-runtime-observation/
```
