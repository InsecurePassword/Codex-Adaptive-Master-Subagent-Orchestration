# Installation

AMS 4.0 installs from canonical published `main`, without Release assets or package ZIPs.

## One-line install

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "irm 'https://github.com/InsecurePassword/Codex-Adaptive-Master-Subagent-Orchestration/raw/refs/heads/main/install.ps1' | iex"
```

Windows requires PowerShell 5.1+ and built-in .NET/PowerShell components.

```bash
curl -fsSL 'https://github.com/InsecurePassword/Codex-Adaptive-Master-Subagent-Orchestration/raw/refs/heads/main/install.sh' | bash
```

Unix requires Bash; `curl`, `awk`, `sort`, `cmp`, `mktemp`, `wc`, `tr`, `grep`, `head`, `tail`, `od`, `find`, `dirname`, `iconv`, `stat`, `chmod`, `hostname`, `basename`, `cp`, `date`, `id`, `mkdir`, `mv`, `rm`, `sleep`; and `sha256sum` or `shasum`.

Installation ends with the installer; AMS performs no automatic audit or project pause.

## Transaction and runtime preservation

Both installers:

1. acquire convergence's shared package/runtime lock;
2. read canonical `install-manifest.txt`, requiring version `4.0` and exact core inventory;
3. reject malformed, duplicate, escaping, linked, redirected, oversized, or unexpected entries;
4. verify every length/SHA-256 and an identical second manifest read;
5. validate `VERSION = 4.0` and all 18 profile markers;
6. validate bounded convergence runtime layout, canonical identities/receipts, ownership, epochs, and timestamps;
7. stage complete skill, snapshot runtime, and install transactionally with rollback;
8. preserve byte-identical profiles and refuse unrecognized differences;
9. hold lock through runtime restoration and backup deletion;
10. preserve project/global settings and unrelated files/profiles.

`.runtime` is user/runtime state, not manifest content. Safe state is only bounded convergence tracking/history under `adaptive-master-subagent-orchestration/.runtime/convergence/`; unsafe state blocks replacement.

## Installed core

```text
adaptive-master-subagent-orchestration/
├── SKILL.md
├── VERSION
├── agents/openai.yaml
├── assets/agent-profiles/        # 18 profiles
└── references/                   # core and lazy contracts
```

Core requires no Python or runtime test framework.

## Configuration

Normative contract: `adaptive-master-subagent-orchestration/references/project-control.md`.

- Missing supported fields use current defaults.
- Unknown fields fail closed.
- Retired top-level `schema_version` is ignored and removed on next authorized write.
- Project completely overrides global.
- Package operations preserve settings.
- `AMS CONFIGURATION UPDATE [PROJECT|GLOBAL]` completes missing fields without altering existing supported values.

## Optional companions

Standard install excludes companions. Copy the required directory from `extensions/` to `$HOME/.agents/skills/` and verify `COMPATIBILITY = 4.0`:

```text
extensions/ams-app-task-lane/
extensions/ams-runtime-observation/
```

Installation does not enable a companion; feature gate/override and trigger remain required, and implicit invocation is off. Observation companion optionally needs Python 3.11+ or PowerShell 5.1+.

## Manual core install

Clone repository; copy `adaptive-master-subagent-orchestration/` to `$HOME/.agents/skills/`; copy all 18 profiles to `$CODEX_HOME/agents/` or `$HOME/.codex/agents/`. Preserve safe `.runtime` only under the shared lock.

## Update and repair

Rerun installer. It locks, validates/preserves runtime, stages complete candidate, and rolls back on failure.

## Downgrade preparation

Older installers may delete AMS 4.0 convergence state. Before authorized downgrade:

1. stop record mutation at safe boundary;
2. acquire `<skill-parent>/.adaptive-master-subagent-orchestration.runtime.lock`;
3. validate/copy `<skill-root>/.runtime/convergence/` outside skill root, preferably `$CODEX_HOME/ams-runtime-export/<UTC-id>/`;
4. record each relative path, length, and SHA-256;
5. release lock, then run older installer.

Do not assume old AMS can resume export. Reimport only into compatible AMS under shared lock after validating it and proving no conflicting active state. Warn that direct downgrade may destroy convergence history and older AMS may reject preserved 4.0 settings.

## Uninstall

Preserve project/global settings and profiles unless separately authorized. Before removing skill root, preserve runtime in place when supported or export it. Remove history only with explicit full-runtime-cleanup authority.

Repository verification is outside the manifest, never installed as core, and never run during project orchestration.
